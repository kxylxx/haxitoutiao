import openpyxl
import re
#import json
import os

def readFile():
    book_list = []
    
    with open("11.txt") as f:
        new_sheet = False
        sheet_name = ''
        for line in f:
            if not line.strip():
                continue
            if line.strip():

                if ord(line.strip()[0]) in (65279, 8220, 8221, 8220):
                # if len(line.strip()) == 2:
                    if new_sheet:
                        new_sheet = False
                    else:
                        new_sheet = True
                        if book_list:
                            book_list = [book_list[i][5:] for i in range(0, len(book_list)) if i % 4]
                            for item in ['举办场馆', '具体地点', '具体时间'][-1::-1]:
                                book_list.insert(0, item)
                            write2Excel(book_list, sheet_name=sheet_name)
                            book_list = []
                elif new_sheet:
                    sheet_name = line.strip()
                else:
                    book_list.append(line.strip())
        if book_list:
            book_list = [book_list[i][5:] for i in range(0, len(book_list)) if i % 4]
            for item in ['举办场馆', '具体地点', '具体时间'][-1::-1]:
                book_list.insert(0, item)
            write2Excel(book_list, sheet_name=sheet_name)


def write2Excel(value, sheet_name=""):
    # wb = openpyxl.load_workbook(path)         # 读取
    # print(wb.sheetnames)

    value = [value[i:i+3] for i in range(0, len(value), 3)]
    path = '3.xlsx'
    flag = os.path.exists(path)                 # 判断文件是否存在，已存在执行if，否则else
    if (flag==True):
        wb = openpyxl.load_workbook(path)
        sheet_list = wb.sheetnames
        if (sheet_name not in sheet_list):          # 判断表是否已经存在
            sheet = wb.create_sheet()               # 新加一个表
            sheet.title = sheet_name
            
            for i in range(0, len(value)):
                for j in range(0, len(value[i])):
                    sheet.cell(row=i+1, column=j+1, value=str(value[i][j]))
            sheet.column_dimensions['A'].width = 44
            sheet.column_dimensions['B'].width = 44
            sheet.column_dimensions['C'].width = 44
            wb.save(path)           # 保存至path
            print("写入数据成功！")
            #print(wb.sheetnames)   # 显示已有的sheet，测试用
            
    else:
        wb = openpyxl.Workbook()
        sheet = wb.active               # 创建一个工作表    
        sheet.title = sheet_name        # 更改表名     
       
        for i in range(0, len(value)):
            for j in range(0, len(value[i])):
                sheet.cell(row=i+1, column=j+1, value=str(value[i][j]))
        sheet.column_dimensions['A'].width = 44
        sheet.column_dimensions['B'].width = 44
        sheet.column_dimensions['C'].width = 44
        wb.save(path)     # 保存至path
        print("写入数据成功！")


readFile()